
# Period Unit Enum

A period is comprised of a unit of time (day, week, month, year) and a count (how many units per period).

For example, to define a "3 month" period one would set the unit as "month" and the count as "3".

## Enumeration

`PeriodUnitEnum`

## Fields

| Name |
|  --- |
| `DAY` |
| `WEEK` |
| `MONTH` |
| `YEAR` |

