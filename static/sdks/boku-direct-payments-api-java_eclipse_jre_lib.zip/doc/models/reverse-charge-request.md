
# Reverse Charge Request

'reverse-charge' Request - General Parameters

## Structure

`ReverseChargeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `MerchantId` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantId() | setMerchantId(String merchantId) |
| `MerchantRequestId` | `String` | Required | Merchant assigned request ID of the original charge-request being reversed<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantRequestId() | setMerchantRequestId(String merchantRequestId) |
| `Country` | `String` | Required | Country code of the original charge to be reversed (same value as the original charge-request)<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | String getCountry() | setCountry(String country) |

## Example (as XML)

```xml
<reverse-charge-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002008</merchant-request-id>
  <country>US</country>
</reverse-charge-request>
```

