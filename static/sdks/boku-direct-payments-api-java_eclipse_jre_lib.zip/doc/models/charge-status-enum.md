
# Charge Status Enum

Status of the charge at the time this response was returned.

If 'in-progress' is returned, the charge call should be re-issued with the same request ID until a final status is reached.
If null, means no charge was created, e.g. because the request was rejected.

## Enumeration

`ChargeStatusEnum`

## Fields

| Name |
|  --- |
| `Success` |
| `Failed` |
| `Inprogress` |

