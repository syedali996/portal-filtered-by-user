
# Begin Single Charge Request

'begin-single-charge' Request - General Parameters

## Structure

`BeginSingleChargeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Country` | `String` | Required | Country code in ISO 3166-1-alpha-2 standard<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | String getCountry() | setCountry(String country) |
| `MerchantId` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantId() | setMerchantId(String merchantId) |
| `MerchantRequestId` | `String` | Required | Unique merchant assigned request ID<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantRequestId() | setMerchantRequestId(String merchantRequestId) |
| `MerchantTransactionId` | `String` | Optional | Merchant assigned transaction ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantTransactionId() | setMerchantTransactionId(String merchantTransactionId) |
| `MerchantData` | `String` | Optional | Merchant supplied meta data. This meta data is returned in the 'begin-single-charge' response and can be available in merchant reports.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | String getMerchantData() | setMerchantData(String merchantData) |
| `MerchantItemDescription` | `String` | Required | A purchase description of the item.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | String getMerchantItemDescription() | setMerchantItemDescription(String merchantItemDescription) |
| `MerchantConsumerId` | `String` | Optional | Consumer id assigned by the merchant<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` | String getMerchantConsumerId() | setMerchantConsumerId(String merchantConsumerId) |
| `Currency` | `String` | Required | ISO 4217 3 letter currency code.<br>**Constraints**: *Pattern*: `^[A-Z]{3}$` | String getCurrency() | setCurrency(String currency) |
| `TotalAmount` | `double` | Required | Total amount to charge, including tax<br>**Constraints**: `>= 0.001` | double getTotalAmount() | setTotalAmount(double totalAmount) |
| `Timeout` | [`Timeout`](../../doc/models/timeout.md) | Optional | Specifies how long to block waiting for a response | Timeout getTimeout() | setTimeout(Timeout timeout) |
| `ConsumerIpAddress` | `String` | Optional | The IP address of the consumer. Must be IPv4 address.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `20` | String getConsumerIpAddress() | setConsumerIpAddress(String consumerIpAddress) |
| `PaymentMethod` | `String` | Required | The payment method the consumer has selected.<br><br>Each wallet provider will be its own payment method. A list of available values will be provided on demand.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getPaymentMethod() | setPaymentMethod(String paymentMethod) |
| `ChargeType` | `String` | Required, Constant | Type of charge<br>**Default**: `"hosted"` | String getChargeType() | setChargeType(String chargeType) |
| `NotificationUrl` | `String` | Optional | Supplies the URL for Boku to send a notification once the charge is complete<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | String getNotificationUrl() | setNotificationUrl(String notificationUrl) |
| `Hosted` | [`BeginSingleChargeRequestHosted`](../../doc/models/begin-single-charge-request-hosted.md) | Required | - | BeginSingleChargeRequestHosted getHosted() | setHosted(BeginSingleChargeRequestHosted hosted) |
| `SellerOfRecord` | [`SellerOfRecord`](../../doc/models/seller-of-record.md) | Optional | Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku. | SellerOfRecord getSellerOfRecord() | setSellerOfRecord(SellerOfRecord sellerOfRecord) |

## Example (as XML)

```xml
<begin-single-charge-request>
  <country>US</country>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1602044513536</merchant-request-id>
  <merchant-transaction-id>1602044514238</merchant-transaction-id>
  <merchant-item-description>Fun Item</merchant-item-description>
  <currency>USD</currency>
  <total-amount>20</total-amount>
  <timeout after="10000" />
  <payment-method>superwallet</payment-method>
  <charge-type>hosted</charge-type>
  <notification-url>https://www.boku.com/notify</notification-url>
  <hosted>
    <forward-url>https://www.boku.com/forward</forward-url>
  </hosted>
</begin-single-charge-request>
```

