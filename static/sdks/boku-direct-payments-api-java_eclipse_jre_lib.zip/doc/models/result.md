
# Result

The 'result' element is defined in every response type. It is used to convey the outcome of an API request.

## Structure

`Result`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Status` | [`ResultStatusEnum`](../../doc/models/result-status-enum.md) | Required | The status of the operation | ResultStatusEnum getStatus() | setStatus(ResultStatusEnum status) |
| `ReasonCode` | `int` | Required | Provides additional information for the status | int getReasonCode() | setReasonCode(int reasonCode) |
| `Message` | `String` | Required | Description of the reason code | String getMessage() | setMessage(String message) |
| `Retriable` | `boolean` | Required | **true** if the request can be retried; **false** otherwise | boolean getRetriable() | setRetriable(boolean retriable) |
| `RetryDelay` | `Integer` | Optional | Minimum milliseconds to delay before re-trying request | Integer getRetryDelay() | setRetryDelay(Integer retryDelay) |
| `InvalidRequestFields` | [`List<InvalidRequestField>`](../../doc/models/invalid-request-field.md) | Optional | - | List<InvalidRequestField> getInvalidRequestFields() | setInvalidRequestFields(List<InvalidRequestField> invalidRequestFields) |

## Example (as XML)

```xml
<result>
  <reason-code>0</reason-code>
  <message>Operation Successful</message>
  <retriable>false</retriable>
  <status>OK</status>
</result>
```

