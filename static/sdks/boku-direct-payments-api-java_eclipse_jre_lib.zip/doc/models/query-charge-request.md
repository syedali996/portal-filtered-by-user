
# Query Charge Request

'query-charge' Request

## Structure

`QueryChargeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Country` | `String` | Required | Country code within which to search for charges<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | String getCountry() | setCountry(String country) |
| `MerchantId` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantId() | setMerchantId(String merchantId) |
| `ChargeId` | `String` | Optional | The charge-id returned from the original charge-response.<br>Will match only a single transaction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `24` | String getChargeId() | setChargeId(String chargeId) |
| `MerchantRequestId` | `String` | Optional | The merchant-request-id of the original charge-request.<br>Will match only a single transaction.<br><br>**Note:** merchant-request-id is only valid within 24 hours of the original charge request. After this time, it will return no results.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantRequestId() | setMerchantRequestId(String merchantRequestId) |
| `MerchantTransactionId` | `String` | Optional | Merchant assigned transaction ID supplied in the original charge-request.<br>May match multiple transactions in the case where the merchant reuses merchant-transaction-ids across different request IDs, as Boku does not enforce uniqueness on this value.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | String getMerchantTransactionId() | setMerchantTransactionId(String merchantTransactionId) |

## Example (as XML)

```xml
<query-charge-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <country>US</country>
  <merchant-transaction-id>9002005</merchant-transaction-id>
</query-charge-request>
```

