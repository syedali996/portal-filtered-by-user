
# Query Charge Response

## Structure

`QueryChargeResponse`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Result` | [`Result`](../../doc/models/result.md) | Required | The 'result' element is defined in every response type. It is used to convey the outcome of an API request. | Result getResult() | setResult(Result result) |
| `Charges` | [`List<Charge>`](../../doc/models/charge.md) | Optional | - | List<Charge> getCharges() | setCharges(List<Charge> charges) |

## Example (as XML)

```xml
<query-charge-response>
  <result>
    <reason-code>0</reason-code>
    <message>Found 1 result(s)</message>
    <retriable>false</retriable>
    <status>OK</status>
  </result>
  <charges>
    <charges>
      <result>
        <reason-code>0</reason-code>
        <message>Operation successful</message>
        <retriable>false</retriable>
        <status>OK</status>
      </result>
      <charge-status>success</charge-status>
      <charge-id>b368363a00bbddbf794eba33</charge-id>
      <timestamp>2015-02-40 04:44:16</timestamp>
      <merchant-id>gatewaymerchant</merchant-id>
      <merchant-transaction-id>9002005</merchant-transaction-id>
      <country>DE</country>
      <network-id>de-super</network-id>
      <currency>USD</currency>
      <total-amount>5</total-amount>
      <merchant-item-description>Puzzle game</merchant-item-description>
    </charges>
  </charges>
</query-charge-response>
```

