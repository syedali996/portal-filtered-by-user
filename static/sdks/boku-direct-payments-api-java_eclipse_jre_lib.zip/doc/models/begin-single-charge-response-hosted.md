
# Begin Single Charge Response Hosted

## Structure

`BeginSingleChargeResponseHosted`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `RedirectUrl` | `String` | Required | URL, where the user should be redirected to so the charge, can be authorized<br>**Constraints**: *Maximum Length*: `2048` | String getRedirectUrl() | setRedirectUrl(String redirectUrl) |

## Example (as XML)

```xml
<hosted>
  <redirect-url>https://www.superwallet.com/authorize</redirect-url>
</hosted>
```

