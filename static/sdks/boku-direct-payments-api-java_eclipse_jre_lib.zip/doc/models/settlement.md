
# Settlement

## Structure

`Settlement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Currency` | `String` | Required | - | String getCurrency() | setCurrency(String currency) |
| `GrossMerchantAmount` | `double` | Required | **Constraints**: `>= 0.001` | double getGrossMerchantAmount() | setGrossMerchantAmount(double grossMerchantAmount) |
| `ExchangeRate` | `double` | Required | - | double getExchangeRate() | setExchangeRate(double exchangeRate) |

## Example (as XML)

```xml
<Settlement>
  <currency>currency0</currency>
  <gross-merchant-amount>104.88</gross-merchant-amount>
  <exchange-rate>144.16</exchange-rate>
</Settlement>
```

