
# Getting Started with Boku Direct Payments API

## Introduction

### API Security

Security is a significant consideration for payment platforms. As part of the registration process for each registered merchant account, merchants receive a security key used to authenticate communications in either direction.

Developers should consult the [Boku API Signature Authentication Guide](page:guides/api-signature-authentication-guide) for additional details with respect to implementing security on the Boku APIs.

### API Usage

When a consumer chooses to use a local payment-method (wallet), the consumer must go through an 'optin' flow to authenticate. This is accomplished using a redirect to the issuer's app or website where the consumer authenticates and completes the opt-in process.

After the consumer adds their local payment-method (wallet), as their registered payment method, the 'charge' method is used to charge the consumer's local payment-method.

If a customer decides to refund a transaction, the 'refund-charge' method can be used to refund the transaction.

### API Versioning

The Boku Payment Gateway API is versioned to provide support for changes to functionality without affecting existing integrations.  Each API URL includes version information that enables distinct functionality across different versions.

There are several types of changes that could result in a new API version:

1. New API functionality – new APIs, new parameters, additional information in responses, improved error reporting.
2. Deprecated API functionality – deprecated APIs, deprecated parameters, deprecated error messages.
3. Changes in functionality – existing functional behavior changes such as the returned result of a call. A warning is changed to an error.  Validation becomes stricter or more lenient.

In these cases, Boku will release a new API version through a new endpoint(s). When new versions of existing APIs are added, support for existing versions is maintained.  Unless otherwise stated, as a rule, compatibility is maintained across versions.  Prior supported endpoints should have unchanged behavior. If an API is deprecated and scheduled to be removed, a notice of not less than 6 months will be given.  Requests for extensions to this period can be considered.

Boku may make changes to the API within an existing version without changing the version number. An example of a non-versioning change would be the addition of an optional field to a request or to a response.

### API Calls

#### URL Scheme

All the below API calls are against URLs that follow the pattern,

`https://${api-node}.boku.com/${api-family}/${api-version}/${api-call}`

Definitions for the above placeholders:

* **api-node**: This follows the pattern '${country}-api4' (e.g. 'us-api4').
  * 'country' is the two letter country code of the end-user's payment-method against which the call is made.
  * The country code is required and is used for more efficient routing of the request.
  * The country code in the url must match the country code supplied in the `optin-request`.`country` element.
* **api-family**: Groups a family of related API methods.
  * In this API, family is either one of:
    * 'optin' - For interacting with the user or handset to obtain billing approval.
    * 'billing' - For actually performing billing operations against the user.
* **api-version**: In this version of the API, this value is always the string '3.0'.
  * Calls under different version numbers may be used in the future to introduce non-compatible API changes.
* **api-call**: The name particular API call or method to invoke, for example 'charge' or 'refund-charge'.
  * This usually matches the XML root element name, sans the '-request' suffix.

Fully qualified API call URLs are documented with each of the example calls detailed below.

## Building

The generated code depends on a few Ruby gems. The references to these gems are added in the gemspec file. The easiest way to resolve the dependencies, build the gem and install it is through Rake:

1. Install Rake if not already installed: `gem install rake`
2. Install Bundler if not already installed: `gem install bundler`
3. From terminal/cmd navigate to the root directory of the SDK.
4. Invoke: `rake install`

Alternatively, you can build and install the gem manually:

1. From terminal/cmd navigate to the root directory of the SDK.
2. Run the build command: `gem build boku_direct_payments_api.gemspec`
3. Run the install command: `gem install boku_direct_payments_api-3.0.0.gem`

![Installing Gem](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&gemVer=3.0.0&gemName=boku_direct_payments_api&step=buildSDK)

## Installation

The following section explains how to use the boku_direct_payments_api ruby gem in a new Rails project using RubyMine&trade;. The basic workflow presented here is also applicable if you prefer using a different editor or IDE.

### 1. Starting a new project

Close any existing projects in RubyMine&trade; by selecting `File -> Close Project`. Next, click on `Create New Project` to create a new project from scratch.

![Create a new project in RubyMine - Step 1](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&step=createNewProject0)

Next, provide `TestApp` as the project name, choose `Rails Application` as the project type, and click `OK`.

![Create a new Rails Application in RubyMine - Step 2](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&step=createNewProject1)

In the next dialog make sure that the correct Ruby SDK is being used (>= 2.6 and < 3.1) and click `OK`.

![Create a new Rails Application in RubyMine - Step 3](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&step=createNewProject2)

### 2. Add reference of the gem

In order to use the Tester gem in the new project we must add a gem reference. Locate the `Gemfile` in the Project Explorer window under the `TestApp` project node. The file contains references to all gems being used in the project. Here, add the reference to the library gem by adding the following line: `gem 'boku_direct_payments_api', '3.0.0'`

![Add new reference to the Gemfile](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&gemVer=3.0.0&gemName=boku_direct_payments_api&step=addReference)

### 3. Adding a new Rails Controller

Once the `TestApp` project is created, a folder named `controllers` will be visible in the *Project Explorer* under the following path: `TestApp > app > controllers`. Right click on this folder and select `New -> Run Rails Generator...`.

![Run Rails Generator on Controllers Folder](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&gemVer=3.0.0&gemName=boku_direct_payments_api&step=addCode0)

Selecting the said option will popup a small window where the generator names are displayed. Here, select the `controller` template.

![Create a new Controller](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&step=addCode1)

Next, a popup window will ask you for a Controller name and included Actions. For controller name provide `Hello` and include an action named `Index` and click `OK`.

![Add a new Controller](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&gemVer=3.0.0&gemName=boku_direct_payments_api&step=addCode2)

A new controller class named `HelloController` will be created in a file named `hello_controller.rb` containing a method named `Index`. In this method, add code for initialization and a sample for its usage.

![Initialize the library](https://apidocs.io/illustration/ruby?workspaceFolder=BokuDirectPaymentsApi&gemName=boku_direct_payments_api&step=addCode3)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `country` | `String` | Country code in ISO 3166-1-alpha-2 standard<br>*Default*: `'jp'` |
| `environment` | Environment | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| `connection` | `Faraday::Connection` | The Faraday connection object passed by the SDK user for making requests |
| `adapter` | `Faraday::Adapter` | The Faraday adapter object passed by the SDK user for performing http requests |
| `timeout` | `Float` | The value to use for connection timeout. <br> **Default: 60** |
| `max_retries` | `Integer` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| `retry_interval` | `Float` | Pause in seconds between retries. <br> **Default: 1** |
| `backoff_factor` | `Float` | The amount to multiply each successive retry's interval amount by in order to provide backoff. <br> **Default: 2** |
| `retry_statuses` | `Array` | A list of HTTP statuses to retry. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524, 408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| `retry_methods` | `Array` | A list of HTTP methods to retry. <br> **Default: %i[get put get put]** |
| `http_callback` | `HttpCallBack` | The Http CallBack allows defining callables for pre and post API calls. |

The API client can be initialized as follows:

```ruby
client = BokuDirectPaymentsApi::Client.new(
  environment: Environment::PRODUCTION,
  country: 'jp',
)
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** |
| environment2 | - |

## List of APIs

* [Charge](doc/controllers/charge.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpResponse](doc/http-response.md)
* [HttpRequest](doc/http-request.md)

