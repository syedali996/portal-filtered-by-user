
# Reverse Charge Request

'reverse-charge' Request - General Parameters

## Structure

`ReverseChargeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `merchant_id` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchant_request_id` | `String` | Required | Merchant assigned request ID of the original charge-request being reversed<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `country` | `String` | Required | Country code of the original charge to be reversed (same value as the original charge-request)<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` |

## Example (as XML)

```xml
<reverse-charge-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1002008</merchant-request-id>
  <country>US</country>
</reverse-charge-request>
```

