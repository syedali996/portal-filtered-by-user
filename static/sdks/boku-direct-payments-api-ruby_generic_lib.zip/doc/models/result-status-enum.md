
# Result Status Enum

The status of the operation

## Enumeration

`ResultStatusEnum`

## Fields

| Name |
|  --- |
| `OK` |
| `ERROR` |

