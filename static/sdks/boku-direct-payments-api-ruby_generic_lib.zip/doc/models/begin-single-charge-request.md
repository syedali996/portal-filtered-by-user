
# Begin Single Charge Request

'begin-single-charge' Request - General Parameters

## Structure

`BeginSingleChargeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `String` | Required | Country code in ISO 3166-1-alpha-2 standard<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` |
| `merchant_id` | `String` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchant_request_id` | `String` | Required | Unique merchant assigned request ID<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchant_transaction_id` | `String` | Optional | Merchant assigned transaction ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchant_data` | `String` | Optional | Merchant supplied meta data. This meta data is returned in the 'begin-single-charge' response and can be available in merchant reports.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `merchant_item_description` | `String` | Required | A purchase description of the item.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `merchant_consumer_id` | `String` | Optional | Consumer id assigned by the merchant<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` |
| `currency` | `String` | Required | ISO 4217 3 letter currency code.<br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `total_amount` | `Float` | Required | Total amount to charge, including tax<br>**Constraints**: `>= 0.001` |
| `timeout` | [`Timeout`](../../doc/models/timeout.md) | Optional | Specifies how long to block waiting for a response |
| `consumer_ip_address` | `String` | Optional | The IP address of the consumer. Must be IPv4 address.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `20` |
| `payment_method` | `String` | Required | The payment method the consumer has selected.<br><br>Each wallet provider will be its own payment method. A list of available values will be provided on demand.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `charge_type` | `String` | Required, Constant | Type of charge<br>**Default**: `'hosted'` |
| `notification_url` | `String` | Optional | Supplies the URL for Boku to send a notification once the charge is complete<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `hosted` | [`BeginSingleChargeRequestHosted`](../../doc/models/begin-single-charge-request-hosted.md) | Required | - |
| `seller_of_record` | [`SellerOfRecord`](../../doc/models/seller-of-record.md) | Optional | Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku. |

## Example (as XML)

```xml
<begin-single-charge-request>
  <country>US</country>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1602044513536</merchant-request-id>
  <merchant-transaction-id>1602044514238</merchant-transaction-id>
  <merchant-item-description>Fun Item</merchant-item-description>
  <currency>USD</currency>
  <total-amount>20</total-amount>
  <timeout after="10000" />
  <payment-method>superwallet</payment-method>
  <charge-type>hosted</charge-type>
  <notification-url>https://www.boku.com/notify</notification-url>
  <hosted>
    <forward-url>https://www.boku.com/forward</forward-url>
  </hosted>
</begin-single-charge-request>
```

