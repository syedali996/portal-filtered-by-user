
# Settlement

## Structure

`Settlement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | `String` | Required | - |
| `gross_merchant_amount` | `Float` | Required | **Constraints**: `>= 0.001` |
| `exchange_rate` | `Float` | Required | - |

## Example (as XML)

```xml
<Settlement>
  <currency>currency0</currency>
  <gross-merchant-amount>104.88</gross-merchant-amount>
  <exchange-rate>144.16</exchange-rate>
</Settlement>
```

