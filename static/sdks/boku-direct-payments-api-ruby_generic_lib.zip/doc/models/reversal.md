
# Reversal

Contains information about the reversal status of this transaction.
If present, charge may be considered reversed. If not present, no reversal request has been received.

## Structure

`Reversal`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `timestamp` | `String` | Required | Time original reverse-charge request was received ("YYYY-MM-DD hh:mm:ss").<br><br>All timestamps are in UTC.<br>**Constraints**: *Pattern*: `^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$` |
| `reversal_id` | `String` | Required | Boku assigned reversal ID allocated at the time of the original reversal request<br>**Constraints**: *Maximum Length*: `24` |

## Example (as XML)

```xml
<reversal>
  <timestamp>2015-02-40 04:44:16</timestamp>
  <reversal-id>tRtbIVXyXVIbtRtytRt</reversal-id>
</reversal>
```

