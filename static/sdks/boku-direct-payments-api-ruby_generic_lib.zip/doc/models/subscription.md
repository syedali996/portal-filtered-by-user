
# Subscription

## Structure

`Subscription`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `is_subscription` | `TrueClass\|FalseClass` | Required | True if the charge is for a subscription, false otherwise |
| `period` | [`Period`](../../doc/models/period.md) | Optional | The period of the subscription (at which interval the consumer is being charged) |
| `renewal` | `TrueClass\|FalseClass` | Optional | False if this is the first charge in a subscription, true if the charge is a renewal (second period onwards) |

## Example (as XML)

```xml
<subscription is-subscription="true">
  <period count="1">
    <unit>month</unit>
  </period>
  <renewal>true</renewal>
</subscription>
```

