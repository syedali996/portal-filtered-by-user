
# Seller of Record

Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku.

## Structure

`SellerOfRecord`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `id` | `String` | Required | ID of seller of record previously registered with Boku. Boku generated Seller of Record id will be 24 character alpha-numeric string.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `24` |

## Example (as XML)

```xml
<seller-of-record>
  <id>73tdolramou0m6jnqyb6pkk3</id>
</seller-of-record>
```

