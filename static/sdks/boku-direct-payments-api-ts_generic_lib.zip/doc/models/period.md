
# Period

The period of the subscription (at which interval the consumer is being charged)

## Structure

`Period`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `unit` | [`PeriodUnitEnum`](../../doc/models/period-unit-enum.md) | Required | A period is comprised of a unit of time (day, week, month, year) and a count (how many units per period).<br><br>For example, to define a "3 month" period one would set the unit as "month" and the count as "3". |
| `count` | `number` | Required | The count of units in the period<br>**Constraints**: `>= 1` |

## Example (as XML)

```xml
<period count="1">
  <unit>month</unit>
</period>
```

