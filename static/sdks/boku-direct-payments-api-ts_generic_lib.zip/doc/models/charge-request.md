
# Charge Request

'charge' Request - General Parameters

## Structure

`ChargeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `merchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchantRequestId` | `string` | Required | Unique merchant assigned request ID<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchantTransactionId` | `string \| undefined` | Optional | Merchant assigned transaction ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchantData` | `string \| undefined` | Optional | Merchant supplied meta data. This meta data is returned in the 'charge' response and can be available in merchant reports.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` |
| `merchantItemDescription` | `string` | Required | A short purchase description that appears on the consumer bill. A string longer than 20 characters will be truncated.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` |
| `optinId` | `string` | Required | Boku assigned consumer opt-in ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `currency` | `string` | Required | ISO 4217 3 letter currency code.<br>**Constraints**: *Pattern*: `^[A-Z]{3}$` |
| `totalAmount` | `number` | Required | Total amount to charge, including tax<br>**Constraints**: `>= 0.001` |
| `timeout` | [`Timeout \| undefined`](../../doc/models/timeout.md) | Optional | Specifies how long to block waiting for a response |
| `consumerIpAddress` | `string \| undefined` | Optional | IP address of consumer. Must be IPv4 address.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `20` |
| `subscription` | [`Subscription \| undefined`](../../doc/models/subscription.md) | Optional | - |
| `sellerOfRecord` | [`SellerOfRecord \| undefined`](../../doc/models/seller-of-record.md) | Optional | Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku. |

## Example (as XML)

```xml
<charge-request>
  <currency>USD</currency>
  <merchant-data>TY235g897qWs</merchant-data>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-item-description>Puzzle game</merchant-item-description>
  <merchant-request-id>1002008</merchant-request-id>
  <merchant-transaction-id>9002005</merchant-transaction-id>
  <optin-id>IVXecDoa2f6Y3oOqp1f7</optin-id>
  <total-amount>5</total-amount>
  <timeout after="10000" />
  <consumer-ip-address>24.196.237.108</consumer-ip-address>
</charge-request>
```

