
# Query Charge Request

'query-charge' Request

## Structure

`QueryChargeRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `country` | `string` | Required | Country code within which to search for charges<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` |
| `merchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `chargeId` | `string \| undefined` | Optional | The charge-id returned from the original charge-response.<br>Will match only a single transaction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `24` |
| `merchantRequestId` | `string \| undefined` | Optional | The merchant-request-id of the original charge-request.<br>Will match only a single transaction.<br><br>**Note:** merchant-request-id is only valid within 24 hours of the original charge request. After this time, it will return no results.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |
| `merchantTransactionId` | `string \| undefined` | Optional | Merchant assigned transaction ID supplied in the original charge-request.<br>May match multiple transactions in the case where the merchant reuses merchant-transaction-ids across different request IDs, as Boku does not enforce uniqueness on this value.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` |

## Example (as XML)

```xml
<query-charge-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <country>US</country>
  <merchant-transaction-id>9002005</merchant-transaction-id>
</query-charge-request>
```

