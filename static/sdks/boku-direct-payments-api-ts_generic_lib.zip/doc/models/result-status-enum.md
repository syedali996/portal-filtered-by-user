
# Result Status Enum

The status of the operation

## Enumeration

`ResultStatusEnum`

## Fields

| Name |
|  --- |
| `oK` |
| `eRROR` |

