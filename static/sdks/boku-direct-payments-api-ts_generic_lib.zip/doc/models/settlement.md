
# Settlement

## Structure

`Settlement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `currency` | `string` | Required | - |
| `grossMerchantAmount` | `number` | Required | **Constraints**: `>= 0.001` |
| `exchangeRate` | `number` | Required | - |

## Example (as XML)

```xml
<Settlement>
  <currency>currency0</currency>
  <gross-merchant-amount>104.88</gross-merchant-amount>
  <exchange-rate>144.16</exchange-rate>
</Settlement>
```

