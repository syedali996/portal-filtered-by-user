
# Settlement

## Structure

`Settlement`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `currency` | `string` | Required | - | getCurrency(): string | setCurrency(string currency): void |
| `grossMerchantAmount` | `float` | Required | **Constraints**: `>= 0.001` | getGrossMerchantAmount(): float | setGrossMerchantAmount(float grossMerchantAmount): void |
| `exchangeRate` | `float` | Required | - | getExchangeRate(): float | setExchangeRate(float exchangeRate): void |

## Example (as XML)

```xml
<Settlement>
  <currency>currency0</currency>
  <gross-merchant-amount>104.88</gross-merchant-amount>
  <exchange-rate>144.16</exchange-rate>
</Settlement>
```

