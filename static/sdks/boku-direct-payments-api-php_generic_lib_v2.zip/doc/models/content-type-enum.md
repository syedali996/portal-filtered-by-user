
# Content Type Enum

## Enumeration

`ContentTypeEnum`

## Fields

| Name |
|  --- |
| `ENUM_APPLICATIONXML` |

