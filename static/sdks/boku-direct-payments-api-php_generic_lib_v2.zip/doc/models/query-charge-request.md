
# Query Charge Request

'query-charge' Request

## Structure

`QueryChargeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `country` | `string` | Required | Country code within which to search for charges<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | getCountry(): string | setCountry(string country): void |
| `merchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantId(): string | setMerchantId(string merchantId): void |
| `chargeId` | `?string` | Optional | The charge-id returned from the original charge-response.<br>Will match only a single transaction.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `24` | getChargeId(): ?string | setChargeId(?string chargeId): void |
| `merchantRequestId` | `?string` | Optional | The merchant-request-id of the original charge-request.<br>Will match only a single transaction.<br><br>**Note:** merchant-request-id is only valid within 24 hours of the original charge request. After this time, it will return no results.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantRequestId(): ?string | setMerchantRequestId(?string merchantRequestId): void |
| `merchantTransactionId` | `?string` | Optional | Merchant assigned transaction ID supplied in the original charge-request.<br>May match multiple transactions in the case where the merchant reuses merchant-transaction-ids across different request IDs, as Boku does not enforce uniqueness on this value.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantTransactionId(): ?string | setMerchantTransactionId(?string merchantTransactionId): void |

## Example (as XML)

```xml
<query-charge-request>
  <merchant-id>gatewaymerchant</merchant-id>
  <country>US</country>
  <merchant-transaction-id>9002005</merchant-transaction-id>
</query-charge-request>
```

