
# Begin Single Charge Request

'begin-single-charge' Request - General Parameters

## Structure

`BeginSingleChargeRequest`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `country` | `string` | Required | Country code in ISO 3166-1-alpha-2 standard<br>**Constraints**: *Pattern*: `^[A-Z]{2}$` | getCountry(): string | setCountry(string country): void |
| `merchantId` | `string` | Required | Boku assigned merchant ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantId(): string | setMerchantId(string merchantId): void |
| `merchantRequestId` | `string` | Required | Unique merchant assigned request ID<br><br>Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantRequestId(): string | setMerchantRequestId(string merchantRequestId): void |
| `merchantTransactionId` | `?string` | Optional | Merchant assigned transaction ID<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getMerchantTransactionId(): ?string | setMerchantTransactionId(?string merchantTransactionId): void |
| `merchantData` | `?string` | Optional | Merchant supplied meta data. This meta data is returned in the 'begin-single-charge' response and can be available in merchant reports.<br>**Constraints**: *Minimum Length*: `0`, *Maximum Length*: `255` | getMerchantData(): ?string | setMerchantData(?string merchantData): void |
| `merchantItemDescription` | `string` | Required | A purchase description of the item.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | getMerchantItemDescription(): string | setMerchantItemDescription(string merchantItemDescription): void |
| `merchantConsumerId` | `?string` | Optional | Consumer id assigned by the merchant<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `64` | getMerchantConsumerId(): ?string | setMerchantConsumerId(?string merchantConsumerId): void |
| `currency` | `string` | Required | ISO 4217 3 letter currency code.<br>**Constraints**: *Pattern*: `^[A-Z]{3}$` | getCurrency(): string | setCurrency(string currency): void |
| `totalAmount` | `float` | Required | Total amount to charge, including tax<br>**Constraints**: `>= 0.001` | getTotalAmount(): float | setTotalAmount(float totalAmount): void |
| `timeout` | [`?Timeout`](../../doc/models/timeout.md) | Optional | Specifies how long to block waiting for a response | getTimeout(): ?Timeout | setTimeout(?Timeout timeout): void |
| `consumerIpAddress` | `?string` | Optional | The IP address of the consumer. Must be IPv4 address.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `20` | getConsumerIpAddress(): ?string | setConsumerIpAddress(?string consumerIpAddress): void |
| `paymentMethod` | `string` | Required | The payment method the consumer has selected.<br><br>Each wallet provider will be its own payment method. A list of available values will be provided on demand.<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `50` | getPaymentMethod(): string | setPaymentMethod(string paymentMethod): void |
| `chargeType` | `string` | Required, Constant | Type of charge<br>**Default**: `'hosted'` | getChargeType(): string | setChargeType(string chargeType): void |
| `notificationUrl` | `?string` | Optional | Supplies the URL for Boku to send a notification once the charge is complete<br>**Constraints**: *Minimum Length*: `1`, *Maximum Length*: `255` | getNotificationUrl(): ?string | setNotificationUrl(?string notificationUrl): void |
| `hosted` | [`BeginSingleChargeRequestHosted`](../../doc/models/begin-single-charge-request-hosted.md) | Required | - | getHosted(): BeginSingleChargeRequestHosted | setHosted(BeginSingleChargeRequestHosted hosted): void |
| `sellerOfRecord` | [`?SellerOfRecord`](../../doc/models/seller-of-record.md) | Optional | Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku. | getSellerOfRecord(): ?SellerOfRecord | setSellerOfRecord(?SellerOfRecord sellerOfRecord): void |

## Example (as XML)

```xml
<begin-single-charge-request>
  <country>US</country>
  <merchant-id>gatewaymerchant</merchant-id>
  <merchant-request-id>1602044513536</merchant-request-id>
  <merchant-transaction-id>1602044514238</merchant-transaction-id>
  <merchant-item-description>Fun Item</merchant-item-description>
  <currency>USD</currency>
  <total-amount>20</total-amount>
  <timeout after="10000" />
  <payment-method>superwallet</payment-method>
  <charge-type>hosted</charge-type>
  <notification-url>https://www.boku.com/notify</notification-url>
  <hosted>
    <forward-url>https://www.boku.com/forward</forward-url>
  </hosted>
</begin-single-charge-request>
```

