
# Subscription

## Structure

`Subscription`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `isSubscription` | `bool` | Required | True if the charge is for a subscription, false otherwise | getIsSubscription(): bool | setIsSubscription(bool isSubscription): void |
| `period` | [`?Period`](../../doc/models/period.md) | Optional | The period of the subscription (at which interval the consumer is being charged) | getPeriod(): ?Period | setPeriod(?Period period): void |
| `renewal` | `?bool` | Optional | False if this is the first charge in a subscription, true if the charge is a renewal (second period onwards) | getRenewal(): ?bool | setRenewal(?bool renewal): void |

## Example (as XML)

```xml
<subscription is-subscription="true">
  <period count="1">
    <unit>month</unit>
  </period>
  <renewal>true</renewal>
</subscription>
```

