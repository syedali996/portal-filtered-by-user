
# Getting Started with Boku Direct Payments API

## Introduction

### API Security

Security is a significant consideration for payment platforms. As part of the registration process for each registered merchant account, merchants receive a security key used to authenticate communications in either direction.

Developers should consult the [Boku API Signature Authentication Guide](page:guides/api-signature-authentication-guide) for additional details with respect to implementing security on the Boku APIs.

### API Usage

When a consumer chooses to use a local payment-method (wallet), the consumer must go through an 'optin' flow to authenticate. This is accomplished using a redirect to the issuer's app or website where the consumer authenticates and completes the opt-in process.

After the consumer adds their local payment-method (wallet), as their registered payment method, the 'charge' method is used to charge the consumer's local payment-method.

If a customer decides to refund a transaction, the 'refund-charge' method can be used to refund the transaction.

### API Versioning

The Boku Payment Gateway API is versioned to provide support for changes to functionality without affecting existing integrations.  Each API URL includes version information that enables distinct functionality across different versions.

There are several types of changes that could result in a new API version:

1. New API functionality – new APIs, new parameters, additional information in responses, improved error reporting.
2. Deprecated API functionality – deprecated APIs, deprecated parameters, deprecated error messages.
3. Changes in functionality – existing functional behavior changes such as the returned result of a call. A warning is changed to an error.  Validation becomes stricter or more lenient.

In these cases, Boku will release a new API version through a new endpoint(s). When new versions of existing APIs are added, support for existing versions is maintained.  Unless otherwise stated, as a rule, compatibility is maintained across versions.  Prior supported endpoints should have unchanged behavior. If an API is deprecated and scheduled to be removed, a notice of not less than 6 months will be given.  Requests for extensions to this period can be considered.

Boku may make changes to the API within an existing version without changing the version number. An example of a non-versioning change would be the addition of an optional field to a request or to a response.

### API Calls

#### URL Scheme

All the below API calls are against URLs that follow the pattern,

`https://${api-node}.boku.com/${api-family}/${api-version}/${api-call}`

Definitions for the above placeholders:

* **api-node**: This follows the pattern '${country}-api4' (e.g. 'us-api4').
  * 'country' is the two letter country code of the end-user's payment-method against which the call is made.
  * The country code is required and is used for more efficient routing of the request.
  * The country code in the url must match the country code supplied in the `optin-request`.`country` element.
* **api-family**: Groups a family of related API methods.
  * In this API, family is either one of:
    * 'optin' - For interacting with the user or handset to obtain billing approval.
    * 'billing' - For actually performing billing operations against the user.
* **api-version**: In this version of the API, this value is always the string '3.0'.
  * Calls under different version numbers may be used in the future to introduce non-compatible API changes.
* **api-call**: The name particular API call or method to invoke, for example 'charge' or 'refund-charge'.
  * This usually matches the XML root element name, sans the '-request' suffix.

Fully qualified API call URLs are documented with each of the example calls detailed below.

## Building

The generated code uses the Newtonsoft Json.NET NuGet Package. If the automatic NuGet package restore is enabled, these dependencies will be installed automatically. Therefore, you will need internet access for build.

* Open the solution (BokuDirectPaymentsAPI.sln) file.

Invoke the build process using Ctrl + Shift + B shortcut key or using the Build menu as shown below.

The build process generates a portable class library, which can be used like a normal class library. More information on how to use can be found at the MSDN Portable Class Libraries documentation.

The supported version is **.NET Standard 2.0**. For checking compatibility of your .NET implementation with the generated library, [click here](https://dotnet.microsoft.com/en-us/platform/dotnet-standard#versions).

## Installation

The following section explains how to use the BokuDirectPaymentsAPI.Standard library in a new project.

### 1. Starting a new project

For starting a new project, right click on the current solution from the solution explorer and choose `Add -> New Project`.

![Add a new project in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=addProject)

Next, choose `Console Application`, provide `TestConsoleProject` as the project name and click OK.

![Create a new Console Application in Visual Studio](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=createProject)

### 2. Set as startup project

The new console project is the entry point for the eventual execution. This requires us to set the `TestConsoleProject` as the start-up project. To do this, right-click on the `TestConsoleProject` and choose `Set as StartUp Project` form the context menu.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=setStartup)

### 3. Add reference of the library project

In order to use the `BokuDirectPaymentsAPI.Standard` library in the new project, first we must add a project reference to the `TestConsoleProject`. First, right click on the `References` node in the solution explorer and click `Add Reference...`

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=addReference)

Next, a window will be displayed where we must set the `checkbox` on `BokuDirectPaymentsAPI.Standard` and click `OK`. By doing this, we have added a reference of the `BokuDirectPaymentsAPI.Standard` project into the new `TestConsoleProject`.

![Creating a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=createReference)

### 4. Write sample code

Once the `TestConsoleProject` is created, a file named `Program.cs` will be visible in the solution explorer with an empty `Main` method. This is the entry point for the execution of the entire solution. Here, you can add code to initialize the client library and acquire the instance of a Controller class. Sample code to initialize the client library and using Controller methods is given in the subsequent sections.

![Adding a project reference](https://apidocs.io/illustration/cs?workspaceFolder=Boku%20Direct%20Payments%20API-CSharp&workspaceName=BokuDirectPaymentsAPI&projectName=BokuDirectPaymentsAPI.Standard&rootNamespace=BokuDirectPaymentsAPI.Standard&step=addCode)

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| `Country` | `string` | Country code in ISO 3166-1-alpha-2 standard<br>*Default*: `"jp"` |
| `Environment` | Environment | The API environment. <br> **Default: `Environment.Production`** |
| `Timeout` | `TimeSpan` | Http client timeout.<br>*Default*: `TimeSpan.FromSeconds(100)` |

The API client can be initialized as follows:

```csharp
BokuDirectPaymentsAPI.Standard.BokuDirectPaymentsAPIClient client = new BokuDirectPaymentsAPI.Standard.BokuDirectPaymentsAPIClient.Builder()
    .Environment(BokuDirectPaymentsAPI.Standard.Environment.Production)
    .Country("jp")
    .Build();
```

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| production | **Default** |
| environment2 | - |

## List of APIs

* [Charge](doc/controllers/charge.md)

## Classes Documentation

* [Utility Classes](doc/utility-classes.md)
* [HttpRequest](doc/http-request.md)
* [HttpResponse](doc/http-response.md)
* [HttpStringResponse](doc/http-string-response.md)
* [HttpContext](doc/http-context.md)
* [HttpClientConfiguration](doc/http-client-configuration.md)
* [HttpClientConfiguration Builder](doc/http-client-configuration-builder.md)
* [IAuthManager](doc/i-auth-manager.md)
* [ApiException](doc/api-exception.md)

