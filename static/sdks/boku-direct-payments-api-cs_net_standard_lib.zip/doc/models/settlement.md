
# Settlement

## Structure

`Settlement`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `Currency` | `string` | Required | - |
| `GrossMerchantAmount` | `double` | Required | **Constraints**: `>= 0.001` |
| `ExchangeRate` | `double` | Required | - |

## Example (as XML)

```xml
<Settlement>
  <currency>currency0</currency>
  <gross-merchant-amount>104.88</gross-merchant-amount>
  <exchange-rate>144.16</exchange-rate>
</Settlement>
```

