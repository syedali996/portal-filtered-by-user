// <copyright file="Settlement.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Settlement.
    /// </summary>
    [XmlRootAttribute("Settlement")]
    public class Settlement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Settlement"/> class.
        /// </summary>
        public Settlement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Settlement"/> class.
        /// </summary>
        /// <param name="currency">currency.</param>
        /// <param name="grossMerchantAmount">grossMerchantAmount.</param>
        /// <param name="exchangeRate">exchangeRate.</param>
        public Settlement(
            string currency,
            double grossMerchantAmount,
            double exchangeRate)
        {
            this.Currency = currency;
            this.GrossMerchantAmount = grossMerchantAmount;
            this.ExchangeRate = exchangeRate;
        }

        /// <summary>
        /// Gets or sets Currency.
        /// </summary>
        [JsonProperty("currency")]
        [XmlElement("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets GrossMerchantAmount.
        /// </summary>
        [JsonProperty("grossMerchantAmount")]
        [XmlElement("gross-merchant-amount")]
        public double GrossMerchantAmount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate.
        /// </summary>
        [JsonProperty("exchangeRate")]
        [XmlElement("exchange-rate")]
        public double ExchangeRate { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Settlement : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Settlement other &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                this.GrossMerchantAmount.Equals(other.GrossMerchantAmount) &&
                this.ExchangeRate.Equals(other.ExchangeRate);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.GrossMerchantAmount = {this.GrossMerchantAmount}");
            toStringOutput.Add($"this.ExchangeRate = {this.ExchangeRate}");
        }
    }
}