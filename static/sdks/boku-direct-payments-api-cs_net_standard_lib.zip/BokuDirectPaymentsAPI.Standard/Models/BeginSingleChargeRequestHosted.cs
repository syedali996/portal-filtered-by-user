// <copyright file="BeginSingleChargeRequestHosted.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BeginSingleChargeRequestHosted.
    /// </summary>
    [XmlRootAttribute("hosted")]
    public class BeginSingleChargeRequestHosted
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeRequestHosted"/> class.
        /// </summary>
        public BeginSingleChargeRequestHosted()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeRequestHosted"/> class.
        /// </summary>
        /// <param name="forwardUrl">forwardUrl.</param>
        /// <param name="useMobileFlow">useMobileFlow.</param>
        public BeginSingleChargeRequestHosted(
            string forwardUrl,
            bool? useMobileFlow = false)
        {
            this.ForwardUrl = forwardUrl;
            this.UseMobileFlow = useMobileFlow;
        }

        /// <summary>
        /// Supplies the URL for Boku to redirect the consumer back to the merchant UI to complete authentication.
        /// </summary>
        [JsonProperty("forwardUrl")]
        [XmlElement("forward-url")]
        public string ForwardUrl { get; set; }

        /// <summary>
        /// True if a mobile-optimized purchase flow should be used for this request, false otherwise.
        /// Example: A non-mobile-optimized flow could display a QR code on the user's mobile. The user would be unable to scan the QR code because they are already on their mobile.
        /// A mobile-optimized flow could display a mobile login page to the user.
        /// </summary>
        [JsonProperty("useMobileFlow", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("use-mobile-flow")]
        public bool? UseMobileFlow { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BeginSingleChargeRequestHosted : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BeginSingleChargeRequestHosted other &&
                ((this.ForwardUrl == null && other.ForwardUrl == null) || (this.ForwardUrl?.Equals(other.ForwardUrl) == true)) &&
                ((this.UseMobileFlow == null && other.UseMobileFlow == null) || (this.UseMobileFlow?.Equals(other.UseMobileFlow) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.ForwardUrl = {(this.ForwardUrl == null ? "null" : this.ForwardUrl == string.Empty ? "" : this.ForwardUrl)}");
            toStringOutput.Add($"this.UseMobileFlow = {(this.UseMobileFlow == null ? "null" : this.UseMobileFlow.ToString())}");
        }
    }
}