// <copyright file="ResultStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ResultStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlRoot("ResultStatus")]
    public enum ResultStatusEnum
    {
        /// <summary>
        /// OK.
        /// </summary>
        [XmlEnum("OK")]
        [EnumMember(Value = "OK")]
        OK,

        /// <summary>
        /// ERROR.
        /// </summary>
        [XmlEnum("ERROR")]
        [EnumMember(Value = "ERROR")]
        ERROR
    }
}