// <copyright file="PeriodUnitEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// PeriodUnitEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlRoot("PeriodUnit")]
    public enum PeriodUnitEnum
    {
        /// <summary>
        /// Day.
        /// </summary>
        [XmlEnum("day")]
        [EnumMember(Value = "day")]
        Day,

        /// <summary>
        /// Week.
        /// </summary>
        [XmlEnum("week")]
        [EnumMember(Value = "week")]
        Week,

        /// <summary>
        /// Month.
        /// </summary>
        [XmlEnum("month")]
        [EnumMember(Value = "month")]
        Month,

        /// <summary>
        /// Year.
        /// </summary>
        [XmlEnum("year")]
        [EnumMember(Value = "year")]
        Year
    }
}