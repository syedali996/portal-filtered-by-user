// <copyright file="ChargeStatusEnum.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Runtime.Serialization;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ChargeStatusEnum.
    /// </summary>
    [JsonConverter(typeof(StringEnumConverter))]
    [XmlRoot("charge-status")]
    public enum ChargeStatusEnum
    {
        /// <summary>
        /// Success.
        /// </summary>
        [XmlEnum("success")]
        [EnumMember(Value = "success")]
        Success,

        /// <summary>
        /// Failed.
        /// </summary>
        [XmlEnum("failed")]
        [EnumMember(Value = "failed")]
        Failed,

        /// <summary>
        /// Inprogress.
        /// </summary>
        [XmlEnum("in-progress")]
        [EnumMember(Value = "in-progress")]
        Inprogress
    }
}