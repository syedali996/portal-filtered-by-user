// <copyright file="Reversal.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Reversal.
    /// </summary>
    [XmlRootAttribute("reversal")]
    public class Reversal
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Reversal"/> class.
        /// </summary>
        public Reversal()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Reversal"/> class.
        /// </summary>
        /// <param name="timestamp">timestamp.</param>
        /// <param name="reversalId">reversalId.</param>
        public Reversal(
            string timestamp,
            string reversalId)
        {
            this.Timestamp = timestamp;
            this.ReversalId = reversalId;
        }

        /// <summary>
        /// Time original reverse-charge request was received ("YYYY-MM-DD hh:mm:ss").
        /// All timestamps are in UTC.
        /// </summary>
        [JsonProperty("timestamp")]
        [XmlElement("timestamp")]
        public string Timestamp { get; set; }

        /// <summary>
        /// Boku assigned reversal ID allocated at the time of the original reversal request
        /// </summary>
        [JsonProperty("reversalId")]
        [XmlElement("reversal-id")]
        public string ReversalId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Reversal : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Reversal other &&
                ((this.Timestamp == null && other.Timestamp == null) || (this.Timestamp?.Equals(other.Timestamp) == true)) &&
                ((this.ReversalId == null && other.ReversalId == null) || (this.ReversalId?.Equals(other.ReversalId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Timestamp = {(this.Timestamp == null ? "null" : this.Timestamp == string.Empty ? "" : this.Timestamp)}");
            toStringOutput.Add($"this.ReversalId = {(this.ReversalId == null ? "null" : this.ReversalId == string.Empty ? "" : this.ReversalId)}");
        }
    }
}