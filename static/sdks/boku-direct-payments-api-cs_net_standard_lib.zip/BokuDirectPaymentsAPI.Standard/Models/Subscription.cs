// <copyright file="Subscription.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Subscription.
    /// </summary>
    [XmlRootAttribute("subscription")]
    public class Subscription
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Subscription"/> class.
        /// </summary>
        public Subscription()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Subscription"/> class.
        /// </summary>
        /// <param name="isSubscription">isSubscription.</param>
        /// <param name="period">period.</param>
        /// <param name="renewal">renewal.</param>
        public Subscription(
            bool isSubscription,
            Models.Period period = null,
            bool? renewal = null)
        {
            this.IsSubscription = isSubscription;
            this.Period = period;
            this.Renewal = renewal;
        }

        /// <summary>
        /// True if the charge is for a subscription, false otherwise
        /// </summary>
        [JsonProperty("isSubscription")]
        [XmlAttribute("is-subscription")]
        public bool IsSubscription { get; set; }

        /// <summary>
        /// The period of the subscription (at which interval the consumer is being charged)
        /// </summary>
        [JsonProperty("period", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("period")]
        public Models.Period Period { get; set; }

        /// <summary>
        /// False if this is the first charge in a subscription, true if the charge is a renewal (second period onwards)
        /// </summary>
        [JsonProperty("renewal", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("renewal")]
        public bool? Renewal { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Subscription : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Subscription other &&
                this.IsSubscription.Equals(other.IsSubscription) &&
                ((this.Period == null && other.Period == null) || (this.Period?.Equals(other.Period) == true)) &&
                ((this.Renewal == null && other.Renewal == null) || (this.Renewal?.Equals(other.Renewal) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.IsSubscription = {this.IsSubscription}");
            toStringOutput.Add($"this.Period = {(this.Period == null ? "null" : this.Period.ToString())}");
            toStringOutput.Add($"this.Renewal = {(this.Renewal == null ? "null" : this.Renewal.ToString())}");
        }
    }
}