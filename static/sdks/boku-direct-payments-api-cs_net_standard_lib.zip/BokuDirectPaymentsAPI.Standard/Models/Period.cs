// <copyright file="Period.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Period.
    /// </summary>
    [XmlRootAttribute("period")]
    public class Period
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Period"/> class.
        /// </summary>
        public Period()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Period"/> class.
        /// </summary>
        /// <param name="unit">unit.</param>
        /// <param name="count">count.</param>
        public Period(
            Models.PeriodUnitEnum unit,
            int count)
        {
            this.Unit = unit;
            this.Count = count;
        }

        /// <summary>
        /// A period is comprised of a unit of time (day, week, month, year) and a count (how many units per period).
        /// For example, to define a "3 month" period one would set the unit as "month" and the count as "3".
        /// </summary>
        [JsonProperty("unit", ItemConverterType = typeof(StringEnumConverter))]
        [XmlElement("unit")]
        public Models.PeriodUnitEnum Unit { get; set; }

        /// <summary>
        /// The count of units in the period
        /// </summary>
        [JsonProperty("count")]
        [XmlAttribute("count")]
        public int Count { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Period : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Period other &&
                this.Unit.Equals(other.Unit) &&
                this.Count.Equals(other.Count);
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Unit = {this.Unit}");
            toStringOutput.Add($"this.Count = {this.Count}");
        }
    }
}