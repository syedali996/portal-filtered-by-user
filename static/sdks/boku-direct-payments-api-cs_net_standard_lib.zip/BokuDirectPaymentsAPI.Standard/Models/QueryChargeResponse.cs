// <copyright file="QueryChargeResponse.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// QueryChargeResponse.
    /// </summary>
    [XmlRootAttribute("query-charge-response")]
    public class QueryChargeResponse
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryChargeResponse"/> class.
        /// </summary>
        public QueryChargeResponse()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryChargeResponse"/> class.
        /// </summary>
        /// <param name="result">result.</param>
        /// <param name="charges">charges.</param>
        public QueryChargeResponse(
            Models.Result result,
            List<Models.Charge> charges = null)
        {
            this.Result = result;
            this.Charges = charges;
        }

        /// <summary>
        /// The 'result' element is defined in every response type. It is used to convey the outcome of an API request.
        /// </summary>
        [JsonProperty("result")]
        [XmlElement("result")]
        public Models.Result Result { get; set; }

        /// <summary>
        /// Gets or sets Charges.
        /// </summary>
        [JsonProperty("charges", NullValueHandling = NullValueHandling.Ignore)]
        [XmlArray("charges")]
        [XmlArrayItem("charge")]
        public List<Models.Charge> Charges { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"QueryChargeResponse : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is QueryChargeResponse other &&
                ((this.Result == null && other.Result == null) || (this.Result?.Equals(other.Result) == true)) &&
                ((this.Charges == null && other.Charges == null) || (this.Charges?.Equals(other.Charges) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Result = {(this.Result == null ? "null" : this.Result.ToString())}");
            toStringOutput.Add($"this.Charges = {(this.Charges == null ? "null" : $"[{string.Join(", ", this.Charges)} ]")}");
        }
    }
}