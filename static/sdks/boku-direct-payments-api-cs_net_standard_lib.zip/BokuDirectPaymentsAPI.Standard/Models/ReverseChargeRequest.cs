// <copyright file="ReverseChargeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ReverseChargeRequest.
    /// </summary>
    [XmlRootAttribute("reverse-charge-request")]
    public class ReverseChargeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReverseChargeRequest"/> class.
        /// </summary>
        public ReverseChargeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ReverseChargeRequest"/> class.
        /// </summary>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="country">country.</param>
        public ReverseChargeRequest(
            string merchantId,
            string merchantRequestId,
            string country)
        {
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.Country = country;
        }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Merchant assigned request ID of the original charge-request being reversed
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Country code of the original charge to be reversed (same value as the original charge-request)
        /// </summary>
        [JsonProperty("country")]
        [XmlElement("country")]
        public string Country { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ReverseChargeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ReverseChargeRequest other &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
        }
    }
}