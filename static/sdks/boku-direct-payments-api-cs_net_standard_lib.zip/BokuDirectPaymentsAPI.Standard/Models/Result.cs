// <copyright file="Result.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// Result.
    /// </summary>
    [XmlRootAttribute("result")]
    public class Result
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Result"/> class.
        /// </summary>
        public Result()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Result"/> class.
        /// </summary>
        /// <param name="status">status.</param>
        /// <param name="reasonCode">reasonCode.</param>
        /// <param name="message">message.</param>
        /// <param name="retriable">retriable.</param>
        /// <param name="retryDelay">retryDelay.</param>
        /// <param name="invalidRequestFields">invalidRequestFields.</param>
        public Result(
            Models.ResultStatusEnum status,
            int reasonCode,
            string message,
            bool retriable,
            int? retryDelay = null,
            List<Models.InvalidRequestField> invalidRequestFields = null)
        {
            this.Status = status;
            this.ReasonCode = reasonCode;
            this.Message = message;
            this.Retriable = retriable;
            this.RetryDelay = retryDelay;
            this.InvalidRequestFields = invalidRequestFields;
        }

        /// <summary>
        /// The status of the operation
        /// </summary>
        [JsonProperty("status", ItemConverterType = typeof(StringEnumConverter))]
        [XmlElement("status")]
        public Models.ResultStatusEnum Status { get; set; }

        /// <summary>
        /// Provides additional information for the status
        /// </summary>
        [JsonProperty("reasonCode")]
        [XmlElement("reason-code")]
        public int ReasonCode { get; set; }

        /// <summary>
        /// Description of the reason code
        /// </summary>
        [JsonProperty("message")]
        [XmlElement("message")]
        public string Message { get; set; }

        /// <summary>
        /// **true** if the request can be retried; **false** otherwise
        /// </summary>
        [JsonProperty("retriable")]
        [XmlElement("retriable")]
        public bool Retriable { get; set; }

        /// <summary>
        /// Minimum milliseconds to delay before re-trying request
        /// </summary>
        [JsonProperty("retryDelay", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("retry-delay")]
        public int? RetryDelay { get; set; }

        /// <summary>
        /// Gets or sets InvalidRequestFields.
        /// </summary>
        [JsonProperty("invalidRequestFields", NullValueHandling = NullValueHandling.Ignore)]
        [XmlArray("invalid-request-fields")]
        [XmlArrayItem("field")]
        public List<Models.InvalidRequestField> InvalidRequestFields { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"Result : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is Result other &&
                this.Status.Equals(other.Status) &&
                this.ReasonCode.Equals(other.ReasonCode) &&
                ((this.Message == null && other.Message == null) || (this.Message?.Equals(other.Message) == true)) &&
                this.Retriable.Equals(other.Retriable) &&
                ((this.RetryDelay == null && other.RetryDelay == null) || (this.RetryDelay?.Equals(other.RetryDelay) == true)) &&
                ((this.InvalidRequestFields == null && other.InvalidRequestFields == null) || (this.InvalidRequestFields?.Equals(other.InvalidRequestFields) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Status = {this.Status}");
            toStringOutput.Add($"this.ReasonCode = {this.ReasonCode}");
            toStringOutput.Add($"this.Message = {(this.Message == null ? "null" : this.Message == string.Empty ? "" : this.Message)}");
            toStringOutput.Add($"this.Retriable = {this.Retriable}");
            toStringOutput.Add($"this.RetryDelay = {(this.RetryDelay == null ? "null" : this.RetryDelay.ToString())}");
            toStringOutput.Add($"this.InvalidRequestFields = {(this.InvalidRequestFields == null ? "null" : $"[{string.Join(", ", this.InvalidRequestFields)} ]")}");
        }
    }
}