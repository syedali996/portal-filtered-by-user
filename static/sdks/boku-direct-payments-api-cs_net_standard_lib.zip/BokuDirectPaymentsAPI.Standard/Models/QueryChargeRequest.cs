// <copyright file="QueryChargeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// QueryChargeRequest.
    /// </summary>
    [XmlRootAttribute("query-charge-request")]
    public class QueryChargeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="QueryChargeRequest"/> class.
        /// </summary>
        public QueryChargeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="QueryChargeRequest"/> class.
        /// </summary>
        /// <param name="country">country.</param>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="chargeId">chargeId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="merchantTransactionId">merchantTransactionId.</param>
        public QueryChargeRequest(
            string country,
            string merchantId,
            string chargeId = null,
            string merchantRequestId = null,
            string merchantTransactionId = null)
        {
            this.Country = country;
            this.MerchantId = merchantId;
            this.ChargeId = chargeId;
            this.MerchantRequestId = merchantRequestId;
            this.MerchantTransactionId = merchantTransactionId;
        }

        /// <summary>
        /// Country code within which to search for charges
        /// </summary>
        [JsonProperty("country")]
        [XmlElement("country")]
        public string Country { get; set; }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// The charge-id returned from the original charge-response.
        /// Will match only a single transaction.
        /// </summary>
        [JsonProperty("chargeId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("charge-id")]
        public string ChargeId { get; set; }

        /// <summary>
        /// The merchant-request-id of the original charge-request.
        /// Will match only a single transaction.
        /// **Note:** merchant-request-id is only valid within 24 hours of the original charge request. After this time, it will return no results.
        /// </summary>
        [JsonProperty("merchantRequestId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Merchant assigned transaction ID supplied in the original charge-request.
        /// May match multiple transactions in the case where the merchant reuses merchant-transaction-ids across different request IDs, as Boku does not enforce uniqueness on this value.
        /// </summary>
        [JsonProperty("merchantTransactionId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-transaction-id")]
        public string MerchantTransactionId { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"QueryChargeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is QueryChargeRequest other &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.ChargeId == null && other.ChargeId == null) || (this.ChargeId?.Equals(other.ChargeId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.MerchantTransactionId == null && other.MerchantTransactionId == null) || (this.MerchantTransactionId?.Equals(other.MerchantTransactionId) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.ChargeId = {(this.ChargeId == null ? "null" : this.ChargeId == string.Empty ? "" : this.ChargeId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.MerchantTransactionId = {(this.MerchantTransactionId == null ? "null" : this.MerchantTransactionId == string.Empty ? "" : this.MerchantTransactionId)}");
        }
    }
}