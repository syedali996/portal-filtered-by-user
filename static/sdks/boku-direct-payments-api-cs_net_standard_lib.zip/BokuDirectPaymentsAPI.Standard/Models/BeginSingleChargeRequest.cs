// <copyright file="BeginSingleChargeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BeginSingleChargeRequest.
    /// </summary>
    [XmlRootAttribute("begin-single-charge-request")]
    public class BeginSingleChargeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeRequest"/> class.
        /// </summary>
        public BeginSingleChargeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeRequest"/> class.
        /// </summary>
        /// <param name="country">country.</param>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="merchantItemDescription">merchantItemDescription.</param>
        /// <param name="currency">currency.</param>
        /// <param name="totalAmount">totalAmount.</param>
        /// <param name="paymentMethod">paymentMethod.</param>
        /// <param name="chargeType">chargeType.</param>
        /// <param name="hosted">hosted.</param>
        /// <param name="merchantTransactionId">merchantTransactionId.</param>
        /// <param name="merchantData">merchantData.</param>
        /// <param name="merchantConsumerId">merchantConsumerId.</param>
        /// <param name="timeout">timeout.</param>
        /// <param name="consumerIpAddress">consumerIpAddress.</param>
        /// <param name="notificationUrl">notificationUrl.</param>
        /// <param name="sellerOfRecord">sellerOfRecord.</param>
        public BeginSingleChargeRequest(
            string country,
            string merchantId,
            string merchantRequestId,
            string merchantItemDescription,
            string currency,
            double totalAmount,
            string paymentMethod,
            string chargeType,
            Models.BeginSingleChargeRequestHosted hosted,
            string merchantTransactionId = null,
            string merchantData = null,
            string merchantConsumerId = null,
            Models.Timeout timeout = null,
            string consumerIpAddress = null,
            string notificationUrl = null,
            Models.SellerOfRecord sellerOfRecord = null)
        {
            this.Country = country;
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.MerchantTransactionId = merchantTransactionId;
            this.MerchantData = merchantData;
            this.MerchantItemDescription = merchantItemDescription;
            this.MerchantConsumerId = merchantConsumerId;
            this.Currency = currency;
            this.TotalAmount = totalAmount;
            this.Timeout = timeout;
            this.ConsumerIpAddress = consumerIpAddress;
            this.PaymentMethod = paymentMethod;
            this.ChargeType = chargeType;
            this.NotificationUrl = notificationUrl;
            this.Hosted = hosted;
            this.SellerOfRecord = sellerOfRecord;
        }

        /// <summary>
        /// Country code in ISO 3166-1-alpha-2 standard
        /// </summary>
        [JsonProperty("country")]
        [XmlElement("country")]
        public string Country { get; set; }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Unique merchant assigned request ID
        /// Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Merchant assigned transaction ID
        /// </summary>
        [JsonProperty("merchantTransactionId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-transaction-id")]
        public string MerchantTransactionId { get; set; }

        /// <summary>
        /// Merchant supplied meta data. This meta data is returned in the 'begin-single-charge' response and can be available in merchant reports.
        /// </summary>
        [JsonProperty("merchantData", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-data")]
        public string MerchantData { get; set; }

        /// <summary>
        /// A purchase description of the item.
        /// </summary>
        [JsonProperty("merchantItemDescription")]
        [XmlElement("merchant-item-description")]
        public string MerchantItemDescription { get; set; }

        /// <summary>
        /// Consumer id assigned by the merchant
        /// </summary>
        [JsonProperty("merchantConsumerId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-consumer-id")]
        public string MerchantConsumerId { get; set; }

        /// <summary>
        /// ISO 4217 3 letter currency code.
        /// </summary>
        [JsonProperty("currency")]
        [XmlElement("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Total amount to charge, including tax
        /// </summary>
        [JsonProperty("totalAmount")]
        [XmlElement("total-amount")]
        public double TotalAmount { get; set; }

        /// <summary>
        /// Specifies how long to block waiting for a response
        /// </summary>
        [JsonProperty("timeout", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("timeout")]
        public Models.Timeout Timeout { get; set; }

        /// <summary>
        /// The IP address of the consumer. Must be IPv4 address.
        /// </summary>
        [JsonProperty("consumerIpAddress", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("consumer-ip-address")]
        public string ConsumerIpAddress { get; set; }

        /// <summary>
        /// The payment method the consumer has selected.
        /// Each wallet provider will be its own payment method. A list of available values will be provided on demand.
        /// </summary>
        [JsonProperty("paymentMethod")]
        [XmlElement("payment-method")]
        public string PaymentMethod { get; set; }

        /// <summary>
        /// Type of charge
        /// </summary>
        [JsonProperty("chargeType")]
        [XmlElement("charge-type")]
        public string ChargeType { get; set; }

        /// <summary>
        /// Supplies the URL for Boku to send a notification once the charge is complete
        /// </summary>
        [JsonProperty("notificationUrl", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("notification-url")]
        public string NotificationUrl { get; set; }

        /// <summary>
        /// Gets or sets Hosted.
        /// </summary>
        [JsonProperty("hosted")]
        [XmlElement("hosted")]
        public Models.BeginSingleChargeRequestHosted Hosted { get; set; }

        /// <summary>
        /// Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku.
        /// </summary>
        [JsonProperty("sellerOfRecord", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("seller-of-record")]
        public Models.SellerOfRecord SellerOfRecord { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BeginSingleChargeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BeginSingleChargeRequest other &&
                ((this.Country == null && other.Country == null) || (this.Country?.Equals(other.Country) == true)) &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.MerchantTransactionId == null && other.MerchantTransactionId == null) || (this.MerchantTransactionId?.Equals(other.MerchantTransactionId) == true)) &&
                ((this.MerchantData == null && other.MerchantData == null) || (this.MerchantData?.Equals(other.MerchantData) == true)) &&
                ((this.MerchantItemDescription == null && other.MerchantItemDescription == null) || (this.MerchantItemDescription?.Equals(other.MerchantItemDescription) == true)) &&
                ((this.MerchantConsumerId == null && other.MerchantConsumerId == null) || (this.MerchantConsumerId?.Equals(other.MerchantConsumerId) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                this.TotalAmount.Equals(other.TotalAmount) &&
                ((this.Timeout == null && other.Timeout == null) || (this.Timeout?.Equals(other.Timeout) == true)) &&
                ((this.ConsumerIpAddress == null && other.ConsumerIpAddress == null) || (this.ConsumerIpAddress?.Equals(other.ConsumerIpAddress) == true)) &&
                ((this.PaymentMethod == null && other.PaymentMethod == null) || (this.PaymentMethod?.Equals(other.PaymentMethod) == true)) &&
                ((this.ChargeType == null && other.ChargeType == null) || (this.ChargeType?.Equals(other.ChargeType) == true)) &&
                ((this.NotificationUrl == null && other.NotificationUrl == null) || (this.NotificationUrl?.Equals(other.NotificationUrl) == true)) &&
                ((this.Hosted == null && other.Hosted == null) || (this.Hosted?.Equals(other.Hosted) == true)) &&
                ((this.SellerOfRecord == null && other.SellerOfRecord == null) || (this.SellerOfRecord?.Equals(other.SellerOfRecord) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Country = {(this.Country == null ? "null" : this.Country == string.Empty ? "" : this.Country)}");
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.MerchantTransactionId = {(this.MerchantTransactionId == null ? "null" : this.MerchantTransactionId == string.Empty ? "" : this.MerchantTransactionId)}");
            toStringOutput.Add($"this.MerchantData = {(this.MerchantData == null ? "null" : this.MerchantData == string.Empty ? "" : this.MerchantData)}");
            toStringOutput.Add($"this.MerchantItemDescription = {(this.MerchantItemDescription == null ? "null" : this.MerchantItemDescription == string.Empty ? "" : this.MerchantItemDescription)}");
            toStringOutput.Add($"this.MerchantConsumerId = {(this.MerchantConsumerId == null ? "null" : this.MerchantConsumerId == string.Empty ? "" : this.MerchantConsumerId)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.TotalAmount = {this.TotalAmount}");
            toStringOutput.Add($"this.Timeout = {(this.Timeout == null ? "null" : this.Timeout.ToString())}");
            toStringOutput.Add($"this.ConsumerIpAddress = {(this.ConsumerIpAddress == null ? "null" : this.ConsumerIpAddress == string.Empty ? "" : this.ConsumerIpAddress)}");
            toStringOutput.Add($"this.PaymentMethod = {(this.PaymentMethod == null ? "null" : this.PaymentMethod == string.Empty ? "" : this.PaymentMethod)}");
            toStringOutput.Add($"this.ChargeType = {(this.ChargeType == null ? "null" : this.ChargeType == string.Empty ? "" : this.ChargeType)}");
            toStringOutput.Add($"this.NotificationUrl = {(this.NotificationUrl == null ? "null" : this.NotificationUrl == string.Empty ? "" : this.NotificationUrl)}");
            toStringOutput.Add($"this.Hosted = {(this.Hosted == null ? "null" : this.Hosted.ToString())}");
            toStringOutput.Add($"this.SellerOfRecord = {(this.SellerOfRecord == null ? "null" : this.SellerOfRecord.ToString())}");
        }
    }
}