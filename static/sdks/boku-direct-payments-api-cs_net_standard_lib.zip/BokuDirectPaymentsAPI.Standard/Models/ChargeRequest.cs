// <copyright file="ChargeRequest.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// ChargeRequest.
    /// </summary>
    [XmlRootAttribute("charge-request")]
    public class ChargeRequest
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeRequest"/> class.
        /// </summary>
        public ChargeRequest()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeRequest"/> class.
        /// </summary>
        /// <param name="merchantId">merchantId.</param>
        /// <param name="merchantRequestId">merchantRequestId.</param>
        /// <param name="merchantItemDescription">merchantItemDescription.</param>
        /// <param name="optinId">optinId.</param>
        /// <param name="currency">currency.</param>
        /// <param name="totalAmount">totalAmount.</param>
        /// <param name="merchantTransactionId">merchantTransactionId.</param>
        /// <param name="merchantData">merchantData.</param>
        /// <param name="timeout">timeout.</param>
        /// <param name="consumerIpAddress">consumerIpAddress.</param>
        /// <param name="subscription">subscription.</param>
        /// <param name="sellerOfRecord">sellerOfRecord.</param>
        public ChargeRequest(
            string merchantId,
            string merchantRequestId,
            string merchantItemDescription,
            string optinId,
            string currency,
            double totalAmount,
            string merchantTransactionId = null,
            string merchantData = null,
            Models.Timeout timeout = null,
            string consumerIpAddress = null,
            Models.Subscription subscription = null,
            Models.SellerOfRecord sellerOfRecord = null)
        {
            this.MerchantId = merchantId;
            this.MerchantRequestId = merchantRequestId;
            this.MerchantTransactionId = merchantTransactionId;
            this.MerchantData = merchantData;
            this.MerchantItemDescription = merchantItemDescription;
            this.OptinId = optinId;
            this.Currency = currency;
            this.TotalAmount = totalAmount;
            this.Timeout = timeout;
            this.ConsumerIpAddress = consumerIpAddress;
            this.Subscription = subscription;
            this.SellerOfRecord = sellerOfRecord;
        }

        /// <summary>
        /// Boku assigned merchant ID
        /// </summary>
        [JsonProperty("merchantId")]
        [XmlElement("merchant-id")]
        public string MerchantId { get; set; }

        /// <summary>
        /// Unique merchant assigned request ID
        /// Multiple requests received with the same request ID in this field will be handled idempotently within the idempotency window.
        /// </summary>
        [JsonProperty("merchantRequestId")]
        [XmlElement("merchant-request-id")]
        public string MerchantRequestId { get; set; }

        /// <summary>
        /// Merchant assigned transaction ID
        /// </summary>
        [JsonProperty("merchantTransactionId", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-transaction-id")]
        public string MerchantTransactionId { get; set; }

        /// <summary>
        /// Merchant supplied meta data. This meta data is returned in the 'charge' response and can be available in merchant reports.
        /// </summary>
        [JsonProperty("merchantData", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("merchant-data")]
        public string MerchantData { get; set; }

        /// <summary>
        /// A short purchase description that appears on the consumer bill. A string longer than 20 characters will be truncated.
        /// </summary>
        [JsonProperty("merchantItemDescription")]
        [XmlElement("merchant-item-description")]
        public string MerchantItemDescription { get; set; }

        /// <summary>
        /// Boku assigned consumer opt-in ID
        /// </summary>
        [JsonProperty("optinId")]
        [XmlElement("optin-id")]
        public string OptinId { get; set; }

        /// <summary>
        /// ISO 4217 3 letter currency code.
        /// </summary>
        [JsonProperty("currency")]
        [XmlElement("currency")]
        public string Currency { get; set; }

        /// <summary>
        /// Total amount to charge, including tax
        /// </summary>
        [JsonProperty("totalAmount")]
        [XmlElement("total-amount")]
        public double TotalAmount { get; set; }

        /// <summary>
        /// Specifies how long to block waiting for a response
        /// </summary>
        [JsonProperty("timeout", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("timeout")]
        public Models.Timeout Timeout { get; set; }

        /// <summary>
        /// IP address of consumer. Must be IPv4 address.
        /// </summary>
        [JsonProperty("consumerIpAddress", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("consumer-ip-address")]
        public string ConsumerIpAddress { get; set; }

        /// <summary>
        /// Gets or sets Subscription.
        /// </summary>
        [JsonProperty("subscription", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("subscription")]
        public Models.Subscription Subscription { get; set; }

        /// <summary>
        /// Optin and Charge Request API can be made for specific Seller of Record previously registered with Boku.
        /// </summary>
        [JsonProperty("sellerOfRecord", NullValueHandling = NullValueHandling.Ignore)]
        [XmlElement("seller-of-record")]
        public Models.SellerOfRecord SellerOfRecord { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"ChargeRequest : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is ChargeRequest other &&
                ((this.MerchantId == null && other.MerchantId == null) || (this.MerchantId?.Equals(other.MerchantId) == true)) &&
                ((this.MerchantRequestId == null && other.MerchantRequestId == null) || (this.MerchantRequestId?.Equals(other.MerchantRequestId) == true)) &&
                ((this.MerchantTransactionId == null && other.MerchantTransactionId == null) || (this.MerchantTransactionId?.Equals(other.MerchantTransactionId) == true)) &&
                ((this.MerchantData == null && other.MerchantData == null) || (this.MerchantData?.Equals(other.MerchantData) == true)) &&
                ((this.MerchantItemDescription == null && other.MerchantItemDescription == null) || (this.MerchantItemDescription?.Equals(other.MerchantItemDescription) == true)) &&
                ((this.OptinId == null && other.OptinId == null) || (this.OptinId?.Equals(other.OptinId) == true)) &&
                ((this.Currency == null && other.Currency == null) || (this.Currency?.Equals(other.Currency) == true)) &&
                this.TotalAmount.Equals(other.TotalAmount) &&
                ((this.Timeout == null && other.Timeout == null) || (this.Timeout?.Equals(other.Timeout) == true)) &&
                ((this.ConsumerIpAddress == null && other.ConsumerIpAddress == null) || (this.ConsumerIpAddress?.Equals(other.ConsumerIpAddress) == true)) &&
                ((this.Subscription == null && other.Subscription == null) || (this.Subscription?.Equals(other.Subscription) == true)) &&
                ((this.SellerOfRecord == null && other.SellerOfRecord == null) || (this.SellerOfRecord?.Equals(other.SellerOfRecord) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.MerchantId = {(this.MerchantId == null ? "null" : this.MerchantId == string.Empty ? "" : this.MerchantId)}");
            toStringOutput.Add($"this.MerchantRequestId = {(this.MerchantRequestId == null ? "null" : this.MerchantRequestId == string.Empty ? "" : this.MerchantRequestId)}");
            toStringOutput.Add($"this.MerchantTransactionId = {(this.MerchantTransactionId == null ? "null" : this.MerchantTransactionId == string.Empty ? "" : this.MerchantTransactionId)}");
            toStringOutput.Add($"this.MerchantData = {(this.MerchantData == null ? "null" : this.MerchantData == string.Empty ? "" : this.MerchantData)}");
            toStringOutput.Add($"this.MerchantItemDescription = {(this.MerchantItemDescription == null ? "null" : this.MerchantItemDescription == string.Empty ? "" : this.MerchantItemDescription)}");
            toStringOutput.Add($"this.OptinId = {(this.OptinId == null ? "null" : this.OptinId == string.Empty ? "" : this.OptinId)}");
            toStringOutput.Add($"this.Currency = {(this.Currency == null ? "null" : this.Currency == string.Empty ? "" : this.Currency)}");
            toStringOutput.Add($"this.TotalAmount = {this.TotalAmount}");
            toStringOutput.Add($"this.Timeout = {(this.Timeout == null ? "null" : this.Timeout.ToString())}");
            toStringOutput.Add($"this.ConsumerIpAddress = {(this.ConsumerIpAddress == null ? "null" : this.ConsumerIpAddress == string.Empty ? "" : this.ConsumerIpAddress)}");
            toStringOutput.Add($"this.Subscription = {(this.Subscription == null ? "null" : this.Subscription.ToString())}");
            toStringOutput.Add($"this.SellerOfRecord = {(this.SellerOfRecord == null ? "null" : this.SellerOfRecord.ToString())}");
        }
    }
}