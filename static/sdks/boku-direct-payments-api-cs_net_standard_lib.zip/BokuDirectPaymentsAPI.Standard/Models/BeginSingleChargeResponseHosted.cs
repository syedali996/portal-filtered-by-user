// <copyright file="BeginSingleChargeResponseHosted.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// BeginSingleChargeResponseHosted.
    /// </summary>
    [XmlRootAttribute("hosted")]
    public class BeginSingleChargeResponseHosted
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeResponseHosted"/> class.
        /// </summary>
        public BeginSingleChargeResponseHosted()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="BeginSingleChargeResponseHosted"/> class.
        /// </summary>
        /// <param name="redirectUrl">redirectUrl.</param>
        public BeginSingleChargeResponseHosted(
            string redirectUrl)
        {
            this.RedirectUrl = redirectUrl;
        }

        /// <summary>
        /// URL, where the user should be redirected to so the charge, can be authorized
        /// </summary>
        [JsonProperty("redirectUrl")]
        [XmlElement("redirect-url")]
        public string RedirectUrl { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"BeginSingleChargeResponseHosted : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is BeginSingleChargeResponseHosted other &&
                ((this.RedirectUrl == null && other.RedirectUrl == null) || (this.RedirectUrl?.Equals(other.RedirectUrl) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.RedirectUrl = {(this.RedirectUrl == null ? "null" : this.RedirectUrl == string.Empty ? "" : this.RedirectUrl)}");
        }
    }
}