// <copyright file="InvalidRequestField.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    /// <summary>
    /// InvalidRequestField.
    /// </summary>
    [XmlRootAttribute("field")]
    public class InvalidRequestField
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvalidRequestField"/> class.
        /// </summary>
        public InvalidRequestField()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="InvalidRequestField"/> class.
        /// </summary>
        /// <param name="path">path.</param>
        /// <param name="reason">reason.</param>
        public InvalidRequestField(
            string path = null,
            string reason = null)
        {
            this.Path = path;
            this.Reason = reason;
        }

        /// <summary>
        /// Property path of the field that was in error. The element or attribute name is given in camel-case, with nested objects delimited by `.` (period)
        /// If there are multiple distinct errors regarding a particular field, it may appear more than once. I.e. `field[path]` is not necessarily unique.
        /// </summary>
        [JsonProperty("path", NullValueHandling = NullValueHandling.Ignore)]
        [XmlAttribute("path")]
        public string Path { get; set; }

        /// <summary>
        /// A descriptive reason why the field was invalid. This message is not localized and so is not appropriate for user messaging.
        /// </summary>
        [JsonProperty("reason", NullValueHandling = NullValueHandling.Ignore)]
        [XmlAttribute("reason")]
        public string Reason { get; set; }

        /// <inheritdoc/>
        public override string ToString()
        {
            var toStringOutput = new List<string>();

            this.ToString(toStringOutput);

            return $"InvalidRequestField : ({string.Join(", ", toStringOutput)})";
        }

        /// <inheritdoc/>
        public override bool Equals(object obj)
        {
            if (obj == null)
            {
                return false;
            }

            if (obj == this)
            {
                return true;
            }

            return obj is InvalidRequestField other &&
                ((this.Path == null && other.Path == null) || (this.Path?.Equals(other.Path) == true)) &&
                ((this.Reason == null && other.Reason == null) || (this.Reason?.Equals(other.Reason) == true));
        }
        
        /// <summary>
        /// ToString overload.
        /// </summary>
        /// <param name="toStringOutput">List of strings.</param>
        protected void ToString(List<string> toStringOutput)
        {
            toStringOutput.Add($"this.Path = {(this.Path == null ? "null" : this.Path == string.Empty ? "" : this.Path)}");
            toStringOutput.Add($"this.Reason = {(this.Reason == null ? "null" : this.Reason == string.Empty ? "" : this.Reason)}");
        }
    }
}