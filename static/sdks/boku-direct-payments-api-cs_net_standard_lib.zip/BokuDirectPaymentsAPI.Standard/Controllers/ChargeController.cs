// <copyright file="ChargeController.cs" company="APIMatic">
// Copyright (c) APIMatic. All rights reserved.
// </copyright>
namespace BokuDirectPaymentsAPI.Standard.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Dynamic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using APIMatic.Core;
    using APIMatic.Core.Types;
    using APIMatic.Core.Utilities;
    using APIMatic.Core.Utilities.Date.Xml;
    using BokuDirectPaymentsAPI.Standard;
    using BokuDirectPaymentsAPI.Standard.Http.Client;
    using BokuDirectPaymentsAPI.Standard.Utilities;
    using Newtonsoft.Json.Converters;
    using System.Net.Http;

    /// <summary>
    /// ChargeController.
    /// </summary>
    public class ChargeController : BaseController
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ChargeController"/> class.
        /// </summary>
        internal ChargeController(GlobalConfiguration globalConfiguration) : base(globalConfiguration) { }

        /// <summary>
        /// The 'charge' request processes a payment against a previously authorized opt-in. The 'optin-id' received in the 'optin'/'confirm-optin' response must be supplied in order to validate the consumer payment method.
        /// If the 'optin-id' and the other parameters of the request are valid, the charge is submitted to the issuer for processing. A 'charge-id' is returned in the API response.
        /// 'Charge' may operate as a synchronous request, fully asynchronous, or synchronous with fallback to asynchronous after a timeout. The timeout is supplied with the request, or can default to a value configurable for the merchant. The 'charge' method returns a unique 'charge-id' in all cases where the request has been accepted for processing, including success, failure, and pending cases.
        /// The 'charge' method is idempotent. If the same request is sent again (with the same 'merchant-request-id'), Boku will return the current status of the transaction. For example:.
        /// * If the transaction has completed successfully, a response code of "0" will be returned.
        /// * If the transaction has completed with a billing error, a response code of "107" will be   returned.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ChargeResponse response from the API call.</returns>
        public Models.ChargeResponse Charge(
                Models.ContentTypeEnum contentType,
                Models.ChargeRequest body)
            => CoreHelper.RunTask(ChargeAsync(contentType, body));

        /// <summary>
        /// The 'charge' request processes a payment against a previously authorized opt-in. The 'optin-id' received in the 'optin'/'confirm-optin' response must be supplied in order to validate the consumer payment method.
        /// If the 'optin-id' and the other parameters of the request are valid, the charge is submitted to the issuer for processing. A 'charge-id' is returned in the API response.
        /// 'Charge' may operate as a synchronous request, fully asynchronous, or synchronous with fallback to asynchronous after a timeout. The timeout is supplied with the request, or can default to a value configurable for the merchant. The 'charge' method returns a unique 'charge-id' in all cases where the request has been accepted for processing, including success, failure, and pending cases.
        /// The 'charge' method is idempotent. If the same request is sent again (with the same 'merchant-request-id'), Boku will return the current status of the transaction. For example:.
        /// * If the transaction has completed successfully, a response code of "0" will be returned.
        /// * If the transaction has completed with a billing error, a response code of "107" will be   returned.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ChargeResponse response from the API call.</returns>
        public async Task<Models.ChargeResponse> ChargeAsync(
                Models.ContentTypeEnum contentType,
                Models.ChargeRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ChargeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/billing/3.0/charge")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "charge-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.ChargeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Retrieves the status and all details of prior charges matching the given request criteria.
        /// Each returned charge element is similar to a charge-response: although some elements are missing, all present elements have the same names, format and meaning as those in the original charge-response.
        /// The query-charge API call is guaranteed to return transactions up to 1 year old. If the transaction was created before that period, this API may return no results.
        /// Criteria are evaluated in an AND fashion, i.e. if more than one field is supplied then all will be used to filter the returned charge elements. In normal usage this is not relevant, since you would only supply one of the three fields by itself.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.QueryChargeResponse response from the API call.</returns>
        public Models.QueryChargeResponse QueryCharge(
                Models.ContentTypeEnum contentType,
                Models.QueryChargeRequest body)
            => CoreHelper.RunTask(QueryChargeAsync(contentType, body));

        /// <summary>
        /// Retrieves the status and all details of prior charges matching the given request criteria.
        /// Each returned charge element is similar to a charge-response: although some elements are missing, all present elements have the same names, format and meaning as those in the original charge-response.
        /// The query-charge API call is guaranteed to return transactions up to 1 year old. If the transaction was created before that period, this API may return no results.
        /// Criteria are evaluated in an AND fashion, i.e. if more than one field is supplied then all will be used to filter the returned charge elements. In normal usage this is not relevant, since you would only supply one of the three fields by itself.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.QueryChargeResponse response from the API call.</returns>
        public async Task<Models.QueryChargeResponse> QueryChargeAsync(
                Models.ContentTypeEnum contentType,
                Models.QueryChargeRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.QueryChargeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/billing/3.0/query-charge")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "query-charge-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.QueryChargeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// Reverses a charge request. This method is typically used when the result of a prior charge request is unknown. This can occur for a number of reasons, including:.
        /// * Network issue.
        /// * Request timed out by merchant.
        /// * Response received but could not be recorded.
        /// * A reversal will be accepted and a status of "OK" returned in almost all cases, regardless   of whether Boku actually received the original charge.
        /// Aside from general request validation errors, a reversal will only be rejected if the original charge request was issued over 1 hour previously. After the 1 hour time period has expired, reversals are no longer allowed - please refund the transaction if required.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.ReverseChargeResponse response from the API call.</returns>
        public Models.ReverseChargeResponse ReverseCharge(
                Models.ContentTypeEnum contentType,
                Models.ReverseChargeRequest body)
            => CoreHelper.RunTask(ReverseChargeAsync(contentType, body));

        /// <summary>
        /// Reverses a charge request. This method is typically used when the result of a prior charge request is unknown. This can occur for a number of reasons, including:.
        /// * Network issue.
        /// * Request timed out by merchant.
        /// * Response received but could not be recorded.
        /// * A reversal will be accepted and a status of "OK" returned in almost all cases, regardless   of whether Boku actually received the original charge.
        /// Aside from general request validation errors, a reversal will only be rejected if the original charge request was issued over 1 hour previously. After the 1 hour time period has expired, reversals are no longer allowed - please refund the transaction if required.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.ReverseChargeResponse response from the API call.</returns>
        public async Task<Models.ReverseChargeResponse> ReverseChargeAsync(
                Models.ContentTypeEnum contentType,
                Models.ReverseChargeRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.ReverseChargeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/billing/3.0/reverse-charge")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "reverse-charge-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.ReverseChargeResponse>(_response)))
              .ExecuteAsync(cancellationToken);

        /// <summary>
        /// The purpose of the 'begin-single-charge' API call is to initiate a one time charge. The 'begin-single-charge' call initiates a process in which a consumer is required to authenticate themselves each time a purchase is requested. This API provides a payment option for consumers who choose not to save a payment method with the merchant.
        /// The Merchant can obtain information on the status of the charge made through the 'begin-single-charge' API in the following ways.
        /// * 'query-charge' API.
        /// * notification to a Merchant's notification URL specified in the 'begin-single-charge' request.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <returns>Returns the Models.BeginSingleChargeResponse response from the API call.</returns>
        public Models.BeginSingleChargeResponse BeginSingleCharge(
                Models.ContentTypeEnum contentType,
                Models.BeginSingleChargeRequest body)
            => CoreHelper.RunTask(BeginSingleChargeAsync(contentType, body));

        /// <summary>
        /// The purpose of the 'begin-single-charge' API call is to initiate a one time charge. The 'begin-single-charge' call initiates a process in which a consumer is required to authenticate themselves each time a purchase is requested. This API provides a payment option for consumers who choose not to save a payment method with the merchant.
        /// The Merchant can obtain information on the status of the charge made through the 'begin-single-charge' API in the following ways.
        /// * 'query-charge' API.
        /// * notification to a Merchant's notification URL specified in the 'begin-single-charge' request.
        /// </summary>
        /// <param name="contentType">Required parameter: Example: .</param>
        /// <param name="body">Required parameter: Example: .</param>
        /// <param name="cancellationToken"> cancellationToken. </param>
        /// <returns>Returns the Models.BeginSingleChargeResponse response from the API call.</returns>
        public async Task<Models.BeginSingleChargeResponse> BeginSingleChargeAsync(
                Models.ContentTypeEnum contentType,
                Models.BeginSingleChargeRequest body,
                CancellationToken cancellationToken = default)
            => await CreateApiCall<Models.BeginSingleChargeResponse>()
              .RequestBuilder(_requestBuilder => _requestBuilder
                  .Setup(HttpMethod.Post, "/billing/3.0/begin-single-charge")
                  .XmlBodySerializer(serializer => XmlUtility.ToXml(body, "begin-single-charge-request")))
              .ResponseHandler(_responseHandler => _responseHandler
                   .Deserializer(_response => XmlUtility.FromXml<Models.BeginSingleChargeResponse>(_response)))
              .ExecuteAsync(cancellationToken);
    }
}